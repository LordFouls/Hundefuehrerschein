<?php
    include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auswertung</title>

</head>
<body>

    <?php
        foreach($_GET as $frage=> $antwort){
            echo 'frage: ' . $frage . " => " . 'antwort: ' . $antwort;
            $data = $conn->query('SELECT `wahrheit` FROM `antwort` WHERE `id_antwort` = ' . $antwort .
                            ' AND `id_frage` = ' . $frage);
            echo ' ist => ' . $data->fetch_assoc()['wahrheit'] . '<br>';
        }
    ?>
    
</body>
</html>