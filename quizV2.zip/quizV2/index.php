<?php
    session_start();

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "hundefuehrerschein";

    $error_login = false;
    $username = "";
    $pass = "";

    // Create connection
    $conn = new mysqli($host, $user, $password, $database);
        
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    /*
    Es ist denke ich sinnvoller die UserID in der session zu speichern.
    Hab gerade bemerkt, dass du keine UserID hast, sondern alles der Username ist. Daher werde ich die Nennung User in session für den Username nutzen, sofern der user angemeldet ist.

    if(isset($_GET['usrname'])){
        $_SESSION['username'] = $_GET['usrname'];
    }

    if(isset($_GET['password'])){
        $_SESSION['password'] = $_GET['password'];
    }
    */

    /* Da ich nichts einfach löschen möchte, habe ich das vorherige einfach rauskommentiert.

    if(isset($_SESSION["username"]) && isset($_SESSION['password'])){
        $username = $_SESSION['username'];
        $password = $_SESSION['password'];
        $sql = "SELECT username FROM kunden WHERE username = '$username' AND password = '$password'";
        $kunden = $conn->query($sql);
        if ($kunden->num_rows > 0) {
            $_SESSION['login'] = true;
        }
        else{
            $_SESSION['login'] = false;
        }
    }
    else{
        $_SESSION['login'] = false;
    }
    */

    $_SESSION['login'] = false;

    if(isset($_REQUEST["username"]) && isset($_REQUEST['password'])){
        $username = $_REQUEST['username'];
        $password = $_REQUEST['password'];
        $sql = "SELECT username,password FROM kunden WHERE username = ?";
        $prep = $conn->prepare($sql);
        $prep->bind_param("s",$username);
        $prep->execute();
        $kunden = $prep->get_result();

        $pwHash = $kunden->fetch_assoc()["password"];

        if ($kunden->num_rows > 0 &&
            password_verify($_REQUEST["password"],$pwHash))
        {
            $_SESSION['login'] = true;
            $_SESSION['User'] = $username;
        }
    }

    if(isset($_SESSION['User'])){
        $username =  $_SESSION['User'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hundequiz</title>
    <link href="index.css" rel="stylesheet">
</head>
<body>

<nav class="main-navbar">
    <?php include 'nav.php'; ?>
</nav>

<div class="body-container">
    <div class="column-text">
        <div class="row">
            <div class="login-container" id="registrieren">
                <?php 
                    //if($_SESSION['login'] == false){ 
                    if(!isset($_SESSION['User'])){
                        include "login&registieren.php";
                    }
                    else{
                        include 'quiz.php';
                    }
                ?>
            </div>
        </div>
    </div>
    <div class="column-karte">

        <div class="karten">

            <a  href="index.php">
                <div class="karte">
                    <h1>Quiz</h1>
                    <span>ohne Ende</span>
                    <div class="circular-progress">
                        <span class="progress-value">&empty;</span>
                    </div>
                </div>
            </a>

            <a href="pruefung.php">
                <div class="karte">
                    <h1>Prüfung</h1>
                    <span>30 Fragen</span>
                    <div class="circular-progress">
                        <span class="progress-value">&empty;</span>
                    </div>
                </div>
            </a>

            <a href="index.php">
                <div class="karte">
                    <h1>Erziehung</h1>
                    <span>Kategorie</span>
                    <div class="circular-progress">
                        <span class="progress-value">&empty;</span>
                    </div>
                </div>
            </a>
            
            <a href="index.php">
                <div class="karte">
                    <h1>Gesundheit</h1>
                    <span>Kategorie</span>
                    <div class="circular-progress">
                        <span class="progress-value">&empty;</span>
                    </div>
                </div>
            </a>

            <a href="index.php">
                <div class="karte">
                    <h1>Recht</h1>
                    <span>Kategorie</span>
                    <div class="circular-progress">
                        <span class="progress-value">&empty;</span>
                    </div>
                </div>
            </a>

            <a href="index.php">
                <div class="karte">
                    <h1>Staßenverkehr</h1>
                    <span>Kategorie</span>
                    <div class="circular-progress">
                        <span class="progress-value">&empty;</span>
                    </div>
                </div>
            </a>

        </div>

    </div>

</div>

<div class="footer">
    <p>
        Backend Developer: Phillip Laue <br>
        Frontend Developer: Cihan Batasul <br>
        Full-stack Developer: Levin-Laurin Grundmeier <br>
        Grafikdesign : Levin-Laurin Grundmeier
    </p>
    <br>
    <p><a style="color: #739a7e;" href="mailto:levin-laurin@protonmail.com">© 2023 Levin-Laurin Grundmeier</a></p>
    <br>
    <p>
        <a style="color: #739a7e;" href="https://www.gnu.org/licenses/gpl-3.0.txt">
            This program is free software: you can redistribute it and/or modify
            it under the terms of the GNU General Public License as published by
            the Free Software Foundation, either version 3 of the License 
        </a>
    </p>
    <br>
</div>  

<!-- JS -->
<?php 
    //if(isset($_SESSION['login'])){ if($_SESSION['login']){ 
    
    //1. warum if(1.){if(2.){}} statt if(1.&&2.){}
    //2. durch meine kleine änderung oben gibt es jetzt User als session variable, welche nur gesetzt ist, sollte die anmeldung erfolgreich gewesen sein.
    //  das bedeutet isset($_SESSION['User']) ist nur true wenn der benutzer angemeldet ist und wir haben zudem gleich zugriff auf den
    //  username für spätere sql abfragen

    if(isset($_SESSION['User'])){
?>
    <script>
        let question = <?php echo json_encode($question_list);?>;
  
        let circularProgress= document.querySelector(".circular-progress");
        let progressValue= document.querySelector(".progress-value");

        let points = 0;
        for(let i = 0; i < question.length; i++){
            points = points + parseInt(question[i].weight);
        }

        let prozent = 100 - (points / question.length);

        if (prozent < 0){
            prozent = 0;
        }

        prozent = parseInt(prozent);

        progressValue.textContent = `${prozent}%`;
        circularProgress.style.background =`conic-gradient(#739a7e ${prozent * 3.6}deg, #ededed 0deg)`;
    </script>
<?php }//} ?>
</body>
</html>

<?php
$conn->close();
?>