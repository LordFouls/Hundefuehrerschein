<?php

session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "hundefuehrerschein";

$error_login = false;
$username = "";
$pass = "";

// Create connection
$conn = new mysqli($host, $user, $password, $database);
    
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET['usrname'])){
    $_SESSION['username'] = $_GET['usrname'];
}

if(isset($_GET['password'])){
    $_SESSION['password'] = $_GET['password'];
}

if(isset($_SESSION["username"]) && isset($_SESSION['password'])){
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $sql = "SELECT username FROM kunden WHERE username = '$username' AND password = '$password'";
    $kunden = $conn->query($sql);
    if ($kunden->num_rows > 0) {
        $_SESSION['login'] = true;
    }
    else{
        $_SESSION['login'] = false;
    }
}
else{
    $_SESSION['login'] = false;
}
?>