<div class="logodiv">
    <div id="ani_normal">
        <img class="logo" title="hund_normal" src="hund.gif">
    </div>
    <?php if($_SESSION['User'] == true){ ?>
        <div id="ani_falsch">
            <img class="logo" src="hund_falsch.gif" title="hund_falsch">
        </div>
        <div id="ani_richtig">
            <img class="logo" src="hund_richtig.gif" title="hunf_richtig">
        </div>
    <?php } ?>
</div>
<div class="titel">
    <h1>Hundeführerschein</h1>
</div>
<div class="linkdiv">

    <ul class="nav-ul">

        <li class="nav-li">
            <a href="index.php">
                <span>Quiz</span> 
            </a>
        </li>

        <li class="nav-li">
            <a href="pruefung.php">
                <span>Prüfung</span> 
            </a>
        </li>

        <li class="nav-li">
            <span>Kategorien</span> 
            <div class="dropdown-content">
                <a href="#">Erziehung</a>
                <a href="#">Recht</a>
                <a href="#">Gesundheit</a>
                <a href="#">Starßenverkehr</a>
            </div>
        </li>
        
        <li class="nav-li">
            <a href="logout.php">
                <span>Ausloggen</span> 
            </a>
        </li>

    </ul>

</div>