<p>
    Backend Developer: Phillip Laue <br>
    Frontend Developer: Cihan Batasul <br>
    Full-stack Developer: Levin-Laurin Grundmeier <br>
    Grafikdesign : Levin-Laurin Grundmeier
</p>
<br>
<p><a style="color: #04AA6D;" href="mailto:levin-laurin@protonmail.com">© 2023 Levin-Laurin Grundmeier</a></p>
<br>
<p>
    <a style="color: #04AA6D;" href="https://www.gnu.org/licenses/gpl-3.0.txt">
        This program is free software: you can redistribute it and/or modify
        it under the terms of the GNU General Public License as published by
        the Free Software Foundation, either version 3 of the License 
    </a>
</p>
<br>