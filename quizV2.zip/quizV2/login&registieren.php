<!DOCTYPE html>
<html>
  <head>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
      /* Style all input fields */
      input {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        margin-top: 6px;
        margin-bottom: 16px;
      }

      /* Style the submit button */
      input[type=submit] {
        background-color: #04AA6D;
        color: white;
      }

      /* Style the container for inputs */
      .container {
        background-color: #f1f1f1;
        padding: 20px;
      }

      /* The message box is shown when the user clicks on the password field */
      #message {
        display:none;
        background: #f1f1f1;
        color: #000;
        position: relative;
        padding: 20px;
        margin-top: 10px;
      }

      #message p {
        padding: 10px 35px;
        font-size: 18px;
      }

      /* Add a green text color and a checkmark when the requirements are right */
      .valid {
        color: green;
      }
      
      .valid:before {
        content: "✔";
      }

      /* Add a red text color and an "x" when the requirements are wrong */
      .invalid {
        color: red;
      }

      .invalid:before {
        content: "✖";
      }

      .floatRight{
        float: right;
      }

      .green{
        color: #04AA6D;
      }
    </style>
  </head>
  <body>

    <div class="container" id="create" style="display: none;">
      <p><h3>Registrierung</h3>Erstelle ein Konto, damit dein Fortschritt gespeichert wird.</p><br>
      <span class="floatRight" id="change2login">hast du schon einen Konto?<a class="green"> log dich ein</a></span>
      
      <form action="registieren.php" method="post">
        <label for="username">Benutzername</label>
        <input type="text" id="username" name="username" maxlength="8" title="Benutzername exsistiert bereitz" required>
        <div id="username_message" style="display: none;">
            <p id="max" class="valid">nicht <b>länger</b> als 8 Buchstaben</p>
            <p id="exsis" class="valid">Benutzername <b>exsistiert</b> bereitz</p>
        </div>

        <label for="email">E-Mail</label>
        <input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="E-Mail Adresse ist unvollständig." required>

        <label for="psw">Password</label>
        <input type="password" id="psw" maxlength="16" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Muss eine Nummer, ein Großbuchstaben, einen Kleinbuchstaben und insgesammt 8 Buchstaben enthalten." required>
        <div id="pws_message" style="display: none;">
            <h3>Password muss das folgende beinhalten:</h3>
            <p id="letter" class="invalid"> Einen <b>klein</b> Buchstaben</p>
            <p id="capital" class="invalid"> Einen <b>groß</b> Buchstaben</p>
            <p id="number" class="invalid"> Eine <b>Nummer</b></p>
            <p id="length" class="invalid"> Minimal <b>8 Buchstaben</b></p>    
        </div>

        <label for="re_pws">Wiederhole Password</label>
        <input type="password" id="re_pws" maxlength="16" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Passwörter müssen übereinstimmen." required>
        <div id="re_pws_message" style="display: none;">
            <h3>Wiederhole Password:</h3>
            <p id="repead" class="invalid"> muss <b>gleich</b> sein</p>
        </div>
        <input type="submit" value="Submit">
      </form>
    </div>

    <div class="container" id="login">
      <p><h3>Anmeldung</h3>Melde dich an, damit dein Fortschritt gespeichert wird.</p><br>
      <span class="floatRight" id="change2create">hast du noch kein Konto?<a class="green"> erstelle eins</a></span>
      <form action="index.php" method="post">
          <label for="username">Benutzername</label>
          <input type="text" id="user" name="username" maxlength="8" title="Benutzername exsistiert bereitz" required>
          <div id="username_message" style="display: none;">
              <p id="max" class="invalid">nicht <b>länger</b> als 8 Buchstaben</p>
          </div>
          <label for="password">Password</label>
          <input type="password" id="password" maxlength="16" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Muss eine Nummer, ein Großbuchstaben, einen Kleinbuchstaben und insgesammt 8 Buchstaben enthalten." required>         
          <input type="submit" value="Submit">
      </form>
    </div>   
          
    <script>
      create_successful = <?php
                            if(isset($_SESSION['create_successful'])){
                               if($_SESSION['create_successful'] == true){
                                echo 'true';
                               }
                               else{
                                echo 'false';
                               }
                            }
                            else{
                              echo 'true';
                            }
                          ?>;

      //wehen he user clicks on the form change text
      document.getElementById("change2create").onclick = function(){
        document.getElementById("login").style.display = "none";
        document.getElementById("create").style.display = "block";
      }
      document.getElementById("change2login").onclick = function(){
        document.getElementById("login").style.display = "block";
        document.getElementById("create").style.display = "none";
      }

      // When the user clicks on the field, show the message box
      document.getElementById("psw").onfocus = function() {
        document.getElementById("pws_message").style.display = "block";
      }
      document.getElementById("re_pws").onfocus = function(){
          document.getElementById("re_pws_message").style.display = "block";
      }
      document.getElementById("username").onfocus = function(){
          document.getElementById("username_message").style.display = "block";
      }

      // When the user clicks outside of the field, hide the message box
      document.getElementById("psw").onblur = function() {
        document.getElementById("pws_message").style.display = "none";
      }
      document.getElementById("re_pws").onblur = function(){
          document.getElementById("re_pws_message").style.display = "none";
      }
      document.getElementById("username").onblur = function(){
        document.getElementById("username_message").style.display = "none";
      }

      // When the user starts to type something inside the field
      document.getElementById("psw").onkeyup = function() {
        // Validate lowercase letters
        var lowerCaseLetters = /[a-z]/g;
        if(document.getElementById("psw").value.match(lowerCaseLetters)) {  
          document.getElementById("letter").classList.remove("invalid");
          document.getElementById("letter").classList.add("valid");
        } 
        else {
          document.getElementById("letter").classList.remove("valid");
          document.getElementById("letter").classList.add("invalid");
        }
        // Validate capital letters
        var upperCaseLetters = /[A-Z]/g;
        if(document.getElementById("psw").value.match(upperCaseLetters)) {  
          document.getElementById("capital").classList.remove("invalid");
          document.getElementById("capital").classList.add("valid");
        } 
        else {
          document.getElementById("capital").classList.remove("valid");
          document.getElementById("capital").classList.add("invalid");
        }

        // Validate numbers
        var numbers = /[0-9]/g;
        if(document.getElementById("psw").value.match(numbers)) {  
          document.getElementById("number").classList.remove("invalid");
          document.getElementById("number").classList.add("valid");
        } 
        else {
          document.getElementById("number").classList.remove("valid");
          document.getElementById("number").classList.add("invalid");
        }
        
        // Validate length
        if(document.getElementById("psw").value.length >= 8) {
          document.getElementById("length").classList.remove("invalid");
          document.getElementById("length").classList.add("valid");
        } 
        else {
          document.getElementById("length").classList.remove("valid");
          document.getElementById("length").classList.add("invalid");
        }

      }

      document.getElementById("re_pws").onkeyup = function(){
        if(this.checkValidity()){
          if(document.getElementById("psw").value == document.getElementById("re_pws").value){
            document.getElementById("repead").classList.remove("invalid");
            document.getElementById("repead").classList.add("valid");
          }
          else{
            document.getElementById("repead").classList.remove("valid");
            document.getElementById("repead").classList.add("invalid");
          }
        
        }

      }
      
      // gucken ob username noch verfügbar  ist
      if(create_successful == true){
        document.getElementById("exsis").classList.remove("invalid");
        document.getElementById("exsis").classList.add("valid");
      }
      else{
        document.getElementById("exsis").classList.remove("valid");
        document.getElementById("exsis").classList.add("invalid");
      }
        
    </script>

  </body>
</html>